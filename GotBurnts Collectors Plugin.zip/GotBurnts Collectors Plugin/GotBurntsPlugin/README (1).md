# 🎒 Collector Plugin — RuneLite

A RuneLite plugin that lets players register as **Collectors** and share their item collection lists with other users of the plugin.

---

## ✨ Features

- **Register as a Collector** — set up a list of up to 20 items you're collecting
- **Right-click → View Collection** — see any other Collector's list on a clean popup panel
- **Unregistered detection** — shows "Unregistered User" if the target hasn't signed up
- **Bank Sync** — quantities automatically update every time you open your bank
- **Goal quantities** — set targets like "5/10 Bandos pieces obtained"
- **Progress tracking** — green/red indicators + progress bar when viewing others

---

## 📁 Project Structure

```
collector-plugin/       ← RuneLite plugin (Java/Maven)
  src/main/java/com/collectorplugin/
    CollectorPlugin.java            ← Main plugin class
    CollectorConfig.java            ← Plugin settings
    ViewCollectionMenuEntry.java    ← Right-click menu injection
    api/
      CollectorApiClient.java       ← HTTP calls to backend
    model/
      CollectionItem.java           ← Single item model
      CollectorProfile.java         ← Full player profile model
    panel/
      CollectionPanel.java          ← Side panel (your own collection)
      ViewCollectionPanel.java      ← Popup when viewing others

collector-server/       ← Node.js/Express backend
  src/server.js                     ← REST API + SQLite storage
  package.json
```

---

## 🚀 Setup

### 1. Deploy the Backend Server

The plugin needs a backend to store and serve collection profiles.

```bash
cd collector-server
npm install
npm start
# Server runs on port 8080
```

**Recommended free/cheap hosts:**
- [Railway](https://railway.app) — easiest, free tier
- [Render](https://render.com) — free tier (sleeps after inactivity)
- [Fly.io](https://fly.io) — free tier
- [DigitalOcean](https://digitalocean.com) — $6/mo smallest droplet

Once deployed, copy your URL (e.g. `https://my-collector.railway.app`) and update in `CollectorApiClient.java`:

```java
private static final String API_BASE = "https://my-collector.railway.app/api";
```

### 2. Build the Plugin

```bash
cd collector-plugin
mvn clean package
```

Then load the resulting JAR in RuneLite's Plugin Hub (Developer mode) or submit to the Plugin Hub.

### 3. Add Plugin Icon

Place a `collector_icon.png` (18×18px) at:
```
src/main/resources/com/collectorplugin/collector_icon.png
```

---

## 🎮 How to Use

### As a Collector (Registering Yourself)

1. Open the **Collector** panel in the RuneLite sidebar
2. Click **Register**
3. Give your collection a label (e.g. "God Wars Sets", "Dragon Slayer Log")
4. Enter up to **20 item names** + optional goal quantities
5. Click **Save & Sync Collection**
6. Open your **bank** — quantities auto-update!

### Viewing Another Player's Collection

1. Right-click any player in-game
2. Select **View Collection**
3. A popup appears with:
   - Their collection list + quantities
   - Green ✓ / Red ✗ for each item
   - Progress bar
   - Last bank sync timestamp
   - OR: "Unregistered User" if they haven't joined

---

## 🔧 API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/profile/:rsn` | Fetch a player's profile (404 if unregistered) |
| PUT | `/api/profile` | Register/update your collection |
| POST | `/api/profile/:rsn/sync` | Push bank quantity updates |
| DELETE | `/api/profile/:rsn` | Unregister |

### Example Profile JSON

```json
{
  "rsn": "Zezima",
  "registered": true,
  "collectionLabel": "God Wars Sets",
  "lastSyncTimestamp": 1716000000000,
  "collectionList": [
    { "itemId": 11802, "itemName": "Armadyl chestplate", "currentQuantity": 1, "goalQuantity": 1 },
    { "itemId": 11832, "itemName": "Bandos chestplate", "currentQuantity": 0, "goalQuantity": 1 }
  ]
}
```

---

## 🛠️ Development Notes

### Bank Sync Flow

1. Player opens bank → `ItemContainerChanged` fires with `InventoryID.BANK`
2. Plugin builds a `Map<itemId, quantity>` of all bank contents
3. For each collection item, resolve item ID via `ItemManager.search(name)`
4. Compare quantities — if changed, push `POST /api/profile/:rsn/sync`
5. Update side panel display

### Item ID Resolution

Item names are stored as strings and resolved to item IDs via RuneLite's `ItemManager`. The first exact match (case-insensitive) is used. If no exact match, the first result is used. This handles most common items well.

### Adding Authentication (Future)

Currently the API trusts the RSN in the request. For a production plugin you'd want to:
1. Use RuneLite's `OAuthService` to verify the player is logged in
2. Sign requests with a session token
3. Validate the token server-side before accepting updates

---

## 🐛 Troubleshooting

**"View Collection" option not appearing**
- Make sure both players have the plugin installed and running
- Check that your server URL is correct in `CollectorApiClient.java`

**Bank sync not working**
- Open your bank while logged in — the sync fires on bank open
- Check the RuneLite console for error logs (`log.warn(...)`)

**Items show wrong quantities**
- Item name must match the exact in-game name for `ItemManager` to resolve it
- Use the exact name shown in your bank (e.g. "Bandos chestplate" not "bandos chest")

---

## 📜 License

MIT — use freely, credit appreciated.
