package com.collectorplugin.panel.src.model;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a registered collector's profile.
 * Stored server-side and fetched when viewing another player.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CollectorProfile {

    /** The player's RSN (RuneScape Name) */
    private String rsn;

    /** Whether this player has registered as a collector */
    private boolean registered;

    /** The list of up to 20 items they are collecting */
    private List<CollectionItem> collectionList = new ArrayList<>();

    /** Unix timestamp of last bank sync */
    private long lastSyncTimestamp;

    /** Optional display label for the collection (e.g. "God Wars Sets") */
    private String collectionLabel;

    /**
     * Returns the number of completed items.
     */
    public int getCompletedCount() {
        return (int) collectionList.stream().filter(CollectionItem::isCompleted).count();
    }

    /**
     * Returns a summary like "7 / 20 obtained"
     */
    public String getSummary() {
        return getCompletedCount() + " / " + collectionList.size() + " obtained";
    }
}
