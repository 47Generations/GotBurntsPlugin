package com.collectorplugin.panel.src.model;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * Represents a single item in a player's collection list.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CollectionItem {

    /** The OSRS item ID */
    private int itemId;

    /** Display name of the item */
    private String itemName;

    /** How many the player currently has (synced from bank) */
    private int currentQuantity;

    /** The target/goal quantity (optional, default 1) */
    private int goalQuantity;

    /**
     * Returns true if the player has met or exceeded the goal quantity.
     */
    public boolean isCompleted() {
        return currentQuantity >= goalQuantity;
    }

    /**
     * Returns a display string like "3 / 10"
     */
    public String getProgressString() {
        if (goalQuantity <= 1) {
            return currentQuantity > 0 ? "✓ Obtained" : "✗ Missing";
        }
        return currentQuantity + " / " + goalQuantity;
    }
}
