package com.collectorplugin.panel.src.main.java.com.gotburnts;

import com.collectorplugin.panel.src.api.CollectorApiClient;
import com.collectorplugin.panel.src.model.CollectionItem;
import com.collectorplugin.panel.src.model.CollectorProfile;
import com.collectorplugin.panel.src.panel.CollectionPanel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.inject.Provides;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.Client;
import net.runelite.api.InventoryID;
import net.runelite.api.Item;
import net.runelite.api.ItemContainer;
import net.runelite.api.events.ItemContainerChanged;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.EventBus;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.game.ItemManager;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.ClientToolbar;
import net.runelite.client.ui.NavigationButton;
import net.runelite.client.util.ImageUtil;

import javax.inject.Inject;
import java.awt.image.BufferedImage;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Collector Plugin — main plugin class.
 *
 * Responsibilities:
 *  - Register/manage the side panel
 *  - Hook into bank open events to sync item quantities
 *  - Delegate API calls via CollectorApiClient
 *  - Persist the player's own collection via ConfigManager
 */
@Slf4j
@PluginDescriptor(
    name = "Collector",
    description = "Register as a collector and share your collection list with other players",
    tags = {"collection", "items", "trading", "social"}
)
public class CollectorPlugin extends Plugin {

    // -------------------------------------------------------------------------
    // Injected dependencies
    // -------------------------------------------------------------------------

    @Inject private Client client;
    @Inject private ClientToolbar clientToolbar;
    @Inject private ConfigManager configManager;
    @Inject private EventBus eventBus;
    @Inject private ItemManager itemManager;
    @Inject private CollectorApiClient apiClient;
    @Inject private ViewCollectionMenuEntry menuEntry;
    @Inject private CollectorConfig config;
    @Inject private Gson gson;

    // -------------------------------------------------------------------------
    // State
    // -------------------------------------------------------------------------

    private CollectionPanel panel;
    private NavigationButton navButton;

    @Getter
    private List<CollectionItem> myCollectionItems = new ArrayList<>();

    private static final int MAX_ITEMS = 20;

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    @Override
    protected void startUp() throws Exception {
        log.info("Collector Plugin started");

        // Load saved collection from config
        loadCollectionFromConfig();

        // Build & register the side panel
        panel = injector.getInstance(CollectionPanel.class);

        final BufferedImage icon = ImageUtil.loadImageResource(getClass(), "/collector_icon.png");
        navButton = NavigationButton.builder()
            .tooltip("Collector")
            .icon(icon)
            .priority(7)
            .panel(panel)
            .build();

        clientToolbar.addNavigation(navButton);

        // Register event subscribers
        eventBus.register(menuEntry);
    }

    @Override
    protected void shutDown() throws Exception {
        log.info("Collector Plugin stopped");
        clientToolbar.removeNavigation(navButton);
        eventBus.unregister(menuEntry);
        panel = null;
    }

    // -------------------------------------------------------------------------
    // Bank sync — fires whenever any item container changes
    // -------------------------------------------------------------------------

    @Subscribe
    public void onItemContainerChanged(ItemContainerChanged event) {
        // Only care about the bank
        if (event.getContainerId() != InventoryID.BANK.getId()) {
            return;
        }

        // Only sync if registered and has items
        if (!config.isRegistered() || myCollectionItems.isEmpty()) {
            return;
        }

        log.debug("Bank opened — syncing collection quantities");

        ItemContainer bank = event.getItemContainer();
        if (bank == null) return;

        // Build a map of itemId -> total quantity in bank
        Map<Integer, Integer> bankQuantities = new HashMap<>();
        for (Item item : bank.getItems()) {
            if (item.getId() > 0) {
                bankQuantities.merge(item.getId(), item.getQuantity(), Integer::sum);
            }
        }

        // Match collection items by name → itemId (using ItemManager)
        // then update quantities
        boolean changed = false;
        for (CollectionItem collectionItem : myCollectionItems) {
            if (collectionItem.getItemId() == 0) {
                // Try to resolve item ID from name
                resolveItemId(collectionItem);
            }

            int qty = bankQuantities.getOrDefault(collectionItem.getItemId(), 0);
            if (qty != collectionItem.getCurrentQuantity()) {
                collectionItem.setCurrentQuantity(qty);
                changed = true;
            }
        }

        if (changed) {
            log.debug("Quantities changed, pushing sync to server");
            pushBankSync();
        }
    }

    // -------------------------------------------------------------------------
    // Collection management
    // -------------------------------------------------------------------------

    /**
     * Save the player's collection (called from the panel's Save button).
     */
    public void saveCollection(String label, List<CollectionItem> items,
                               Runnable onSuccess, Consumer<String> onFailure) {
        if (items.size() > MAX_ITEMS) {
            onFailure.accept("Maximum " + MAX_ITEMS + " items allowed");
            return;
        }

        myCollectionItems = new ArrayList<>(items);

        // Persist locally
        saveCollectionToConfig();

        // Push to server if registered
        if (config.isRegistered()) {
            CollectorProfile profile = buildMyProfile(label);
            apiClient.saveProfile(profile,
                ok -> {
                    log.info("Collection saved to server");
                    onSuccess.run();
                },
                err -> {
                    log.warn("Failed to save collection: {}", err);
                    onFailure.accept(err);
                }
            );
        } else {
            onSuccess.run();
        }
    }

    /**
     * Toggle registration state.
     */
    public void setRegistered(boolean registered) {
        configManager.setConfiguration("collectorplugin", "isRegistered", registered);

        if (!registered) {
            // Optionally: notify server to remove profile
            String rsn = getLocalRsn();
            if (rsn != null) {
                log.info("Player unregistered: {}", rsn);
                // apiClient.deleteProfile(rsn, ...); // implement if desired
            }
        }
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private void pushBankSync() {
        String rsn = getLocalRsn();
        if (rsn == null) return;

        // Update panel quantities
        if (panel != null) {
            panel.updateQuantities(myCollectionItems);
        }

        // Push to server
        apiClient.syncBankQuantities(rsn, myCollectionItems,
            ok -> log.debug("Bank sync pushed successfully"),
            err -> log.warn("Bank sync failed: {}", err)
        );

        // Also persist updated quantities locally
        saveCollectionToConfig();
    }

    private void resolveItemId(CollectionItem item) {
        // ItemManager.search returns a list of matching items
        // We take the first exact match (case-insensitive)
        List<net.runelite.http.api.item.ItemPrice> results =
            itemManager.search(item.getItemName());

        if (results != null) {
            for (net.runelite.http.api.item.ItemPrice result : results) {
                if (result.getName().equalsIgnoreCase(item.getItemName())) {
                    item.setItemId(result.getId());
                    return;
                }
            }
            // Fallback: take first result
            if (!results.isEmpty()) {
                item.setItemId(results.get(0).getId());
                item.setItemName(results.get(0).getName());
            }
        }
    }

    private CollectorProfile buildMyProfile(String label) {
        CollectorProfile profile = new CollectorProfile();
        profile.setRsn(getLocalRsn());
        profile.setRegistered(true);
        profile.setCollectionLabel(label);
        profile.setCollectionList(myCollectionItems);
        profile.setLastSyncTimestamp(System.currentTimeMillis());
        return profile;
    }

    private String getLocalRsn() {
        if (client.getLocalPlayer() != null) {
            return client.getLocalPlayer().getName();
        }
        return null;
    }

    // -------------------------------------------------------------------------
    // Persistence (config-backed storage)
    // -------------------------------------------------------------------------

    private void saveCollectionToConfig() {
        String json = gson.toJson(myCollectionItems);
        configManager.setConfiguration("collectorplugin", "collectionItems", json);
    }

    private void loadCollectionFromConfig() {
        String json = configManager.getConfiguration("collectorplugin", "collectionItems");
        if (json == null || json.equals("[]") || json.isEmpty()) {
            myCollectionItems = new ArrayList<>();
            return;
        }
        try {
            Type listType = new TypeToken<List<CollectionItem>>() {}.getType();
            myCollectionItems = gson.fromJson(json, listType);
            if (myCollectionItems == null) myCollectionItems = new ArrayList<>();
        } catch (Exception e) {
            log.warn("Failed to parse saved collection, resetting", e);
            myCollectionItems = new ArrayList<>();
        }
    }

    // -------------------------------------------------------------------------
    // Guice config binding
    // -------------------------------------------------------------------------

    @Provides
    CollectorConfig provideConfig(ConfigManager configManager) {
        return configManager.getConfig(CollectorConfig.class);
    }
}
