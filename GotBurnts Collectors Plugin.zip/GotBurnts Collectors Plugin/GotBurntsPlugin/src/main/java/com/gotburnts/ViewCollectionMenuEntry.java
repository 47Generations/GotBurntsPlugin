package com.collectorplugin.panel.src.main.java.com.gotburnts;

import com.collectorplugin.panel.src.api.CollectorApiClient;
import com.collectorplugin.panel.src.model.CollectorProfile;
import com.collectorplugin.panel.src.panel.ViewCollectionPanel;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.Client;
import net.runelite.api.MenuAction;
import net.runelite.api.MenuEntry;
import net.runelite.api.events.MenuEntryAdded;
import net.runelite.api.events.MenuOptionClicked;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.util.Text;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.swing.*;
import java.awt.*;

/**
 * Responsible for injecting the "View Collection" right-click menu entry
 * on other players and handling the click.
 */
@Slf4j
@Singleton
public class ViewCollectionMenuEntry {

    private static final String MENU_OPTION = "View Collection";
    private static final String MENU_TARGET_SUFFIX = " (Collector)";

    @Inject
    private Client client;

    @Inject
    private CollectorApiClient apiClient;

    // =========================================================================
    // Menu Injection
    // =========================================================================

    /**
     * Called every time a right-click menu entry is about to be added.
     * We listen for player-type actions (Trade, Lookup, etc.) and insert
     * our "View Collection" option directly after them.
     */
    @Subscribe
    public void onMenuEntryAdded(MenuEntryAdded event) {
        // Only inject on player actions
        int type = event.getType();
        if (type != MenuAction.RUNELITE.getId()
            && type != MenuAction.PLAYER_SECOND_OPTION.getId()
            && type != MenuAction.PLAYER_THIRD_OPTION.getId()
            && type != MenuAction.PLAYER_FOURTH_OPTION.getId()
            && type != MenuAction.PLAYER_FIFTH_OPTION.getId()
            && type != MenuAction.RUNELITE_PLAYER.getId()) {
            return;
        }

        // Don't add on our own player name
        String target = Text.removeTags(event.getTarget());
        String localName = client.getLocalPlayer() != null
            ? client.getLocalPlayer().getName() : null;
        if (target.equals(localName)) {
            return;
        }

        // Inject the "View Collection" option
        client.createMenuEntry(-1)
            .setOption(MENU_OPTION)
            .setTarget(event.getTarget())
            .setType(MenuAction.RUNELITE_PLAYER)
            .setIdentifier(event.getIdentifier());
    }

    // =========================================================================
    // Menu Click Handler
    // =========================================================================

    /**
     * Called when any right-click menu option is clicked.
     * We intercept our "View Collection" option here.
     */
    @Subscribe
    public void onMenuOptionClicked(MenuOptionClicked event) {
        if (!event.getMenuOption().equals(MENU_OPTION)) {
            return;
        }

        String targetName = Text.removeTags(event.getMenuTarget());
        if (targetName.isEmpty()) {
            return;
        }

        log.debug("View Collection clicked for player: {}", targetName);

        // Fetch the profile async, then show the panel on the EDT
        apiClient.fetchProfile(
            targetName,
            profile -> SwingUtilities.invokeLater(() -> showCollectionPanel(profile)),
            err -> SwingUtilities.invokeLater(() -> showErrorPanel(targetName, err))
        );
    }

    // =========================================================================
    // Panel Display
    // =========================================================================

    private void showCollectionPanel(CollectorProfile profile) {
        Frame parentFrame = findParentFrame();
        new ViewCollectionPanel(parentFrame, profile);
    }

    private void showErrorPanel(String rsn, String error) {
        log.warn("Failed to fetch collection for {}: {}", rsn, error);
        JOptionPane.showMessageDialog(
            null,
            "Could not load collection for " + rsn + ":\n" + error,
            "Collector Plugin",
            JOptionPane.WARNING_MESSAGE
        );
    }

    private Frame findParentFrame() {
        for (Window window : Window.getWindows()) {
            if (window instanceof Frame && window.isVisible()) {
                return (Frame) window;
            }
        }
        return null;
    }
}
