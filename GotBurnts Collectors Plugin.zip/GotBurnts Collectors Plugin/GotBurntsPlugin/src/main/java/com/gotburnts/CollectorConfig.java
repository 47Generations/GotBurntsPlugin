package com.collectorplugin.panel.src.main.java.com.gotburnts;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;
import net.runelite.client.config.ConfigSection;

@ConfigGroup("collectorplugin")
public interface CollectorConfig extends Config {

    @ConfigSection(
        name = "My Collection",
        description = "Settings for your collection registration",
        position = 0
    )
    String myCollectionSection = "myCollection";

    // -------------------------------------------------------------------------
    // Registration
    // -------------------------------------------------------------------------

    @ConfigItem(
        keyName = "isRegistered",
        name = "Registered as Collector",
        description = "Whether you have registered as a collector",
        section = myCollectionSection,
        position = 0
    )
    default boolean isRegistered() {
        return false;
    }

    @ConfigItem(
        keyName = "collectionLabel",
        name = "Collection Label",
        description = "A short label for your collection (e.g. 'God Wars Sets', 'Dragon Slayer')",
        section = myCollectionSection,
        position = 1
    )
    default String collectionLabel() {
        return "My Collection";
    }

    // -------------------------------------------------------------------------
    // Items 1–20 (item IDs stored as comma-separated: "itemId:goalQty")
    // -------------------------------------------------------------------------

    @ConfigItem(
        keyName = "collectionItems",
        name = "Collection Items (JSON)",
        description = "Internal storage for your 20 collection items. Use the plugin panel to edit.",
        section = myCollectionSection,
        position = 2,
        hidden = true  // Managed via the UI panel, not directly
    )
    default String collectionItemsJson() {
        return "[]";
    }

    // -------------------------------------------------------------------------
    // Display Options
    // -------------------------------------------------------------------------

    @ConfigSection(
        name = "Display",
        description = "How the collection panel looks",
        position = 1
    )
    String displaySection = "display";

    @ConfigItem(
        keyName = "showCompletedItems",
        name = "Show Completed Items",
        description = "Show items you have already obtained in the collection panel",
        section = displaySection,
        position = 0
    )
    default boolean showCompletedItems() {
        return true;
    }

    @ConfigItem(
        keyName = "highlightCompleted",
        name = "Highlight Completed",
        description = "Highlight completed items in green in the collection panel",
        section = displaySection,
        position = 1
    )
    default boolean highlightCompleted() {
        return true;
    }
}
