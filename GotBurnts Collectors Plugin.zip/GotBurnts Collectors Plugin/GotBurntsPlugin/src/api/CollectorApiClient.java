package com.collectorplugin.panel.src.api;

import com.collectorplugin.panel.src.model.CollectionItem;
import com.collectorplugin.panel.src.model.CollectorProfile;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.IOException;
import java.util.List;
import java.util.function.Consumer;

/**
 * Handles all communication with the Collector Plugin backend API.
 *
 * API Base URL should point to your hosted backend (see server/ directory).
 * During development you can run the server locally on localhost:8080.
 */
@Slf4j
@Singleton
public class CollectorApiClient {

    // Replace with your hosted backend URL when deploying
    private static final String API_BASE = "https://your-collector-api.com/api";
    // For local dev: private static final String API_BASE = "http://localhost:8080/api";

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    @Inject
    private OkHttpClient httpClient;

    @Inject
    private Gson gson;

    // -------------------------------------------------------------------------
    // Fetch another player's collection profile
    // -------------------------------------------------------------------------

    /**
     * Asynchronously fetch a player's collection profile by RSN.
     *
     * @param rsn       the player's RuneScape name
     * @param onSuccess called with the CollectorProfile on success
     * @param onFailure called with an error message on failure
     */
    public void fetchProfile(String rsn, Consumer<CollectorProfile> onSuccess, Consumer<String> onFailure) {
        String url = API_BASE + "/profile/" + HttpUrl.encode(rsn);

        Request request = new Request.Builder()
                .url(url)
                .get()
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                log.warn("Failed to fetch collector profile for {}: {}", rsn, e.getMessage());
                onFailure.accept("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try (ResponseBody body = response.body()) {
                    if (response.code() == 404) {
                        // Player is not registered
                        CollectorProfile unregistered = new CollectorProfile();
                        unregistered.setRsn(rsn);
                        unregistered.setRegistered(false);
                        onSuccess.accept(unregistered);
                        return;
                    }

                    if (!response.isSuccessful() || body == null) {
                        onFailure.accept("Server error: " + response.code());
                        return;
                    }

                    CollectorProfile profile = gson.fromJson(body.string(), CollectorProfile.class);
                    onSuccess.accept(profile);
                }
            }
        });
    }

    // -------------------------------------------------------------------------
    // Register / update the local player's profile
    // -------------------------------------------------------------------------

    /**
     * Register or update the current player's collection list on the server.
     *
     * @param profile   the player's full profile to upload
     * @param onSuccess called with true on success
     * @param onFailure called with an error message on failure
     */
    public void saveProfile(CollectorProfile profile, Consumer<Boolean> onSuccess, Consumer<String> onFailure) {
        String json = gson.toJson(profile);
        RequestBody body = RequestBody.create(json, JSON);

        Request request = new Request.Builder()
                .url(API_BASE + "/profile")
                .put(body)
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                log.warn("Failed to save collector profile: {}", e.getMessage());
                onFailure.accept("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                response.close();
                if (response.isSuccessful()) {
                    onSuccess.accept(true);
                } else {
                    onFailure.accept("Server error: " + response.code());
                }
            }
        });
    }

    // -------------------------------------------------------------------------
    // Sync bank quantities
    // -------------------------------------------------------------------------

    /**
     * Push updated bank quantities for the player's collection items to the server.
     *
     * @param rsn       the player's RSN
     * @param items     the updated list of collection items with current quantities
     * @param onSuccess called on success
     * @param onFailure called with an error message on failure
     */
    public void syncBankQuantities(String rsn, List<CollectionItem> items,
                                   Consumer<Boolean> onSuccess, Consumer<String> onFailure) {
        String json = gson.toJson(items);
        RequestBody body = RequestBody.create(json, JSON);

        String url = API_BASE + "/profile/" + HttpUrl.encode(rsn) + "/sync";

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                log.warn("Failed to sync bank quantities: {}", e.getMessage());
                onFailure.accept("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                response.close();
                if (response.isSuccessful()) {
                    log.debug("Bank quantities synced for {}", rsn);
                    onSuccess.accept(true);
                } else {
                    onFailure.accept("Server error: " + response.code());
                }
            }
        });
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private static String encode(String value) {
        return value.replace(" ", "%20");
    }
}
