package com.collectorplugin.panel.src.panel;

import com.collectorplugin.panel.src.model.CollectionItem;
import com.collectorplugin.panel.src.model.CollectorProfile;
import net.runelite.client.ui.ColorScheme;
import net.runelite.client.ui.FontManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * A floating popup panel shown when a player right-clicks another player
 * and selects "View Collection".
 *
 * Shows either:
 *  - "Unregistered User" if the target hasn't registered
 *  - Their full collection list with quantities if they have
 */
public class ViewCollectionPanel extends JDialog {

    private static final Color BG_COLOR = new Color(30, 30, 30);
    private static final Color HEADER_COLOR = new Color(255, 152, 0);
    private static final Color COMPLETED_COLOR = new Color(76, 175, 80);
    private static final Color MISSING_COLOR = new Color(244, 67, 54);
    private static final Color CARD_BG = new Color(42, 42, 42);
    private static final Color BORDER_COLOR = new Color(65, 65, 65);

    public ViewCollectionPanel(Frame parent, CollectorProfile profile) {
        super(parent, "Collector: " + profile.getRsn(), false);

        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(BG_COLOR);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(BG_COLOR);
        content.setBorder(new EmptyBorder(12, 14, 12, 14));

        if (!profile.isRegistered()) {
            buildUnregisteredView(content, profile.getRsn());
        } else {
            buildCollectionView(content, profile);
        }

        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setBorder(null);
        scrollPane.setBackground(BG_COLOR);
        scrollPane.getViewport().setBackground(BG_COLOR);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        add(scrollPane);

        // Size based on content
        int height = profile.isRegistered()
            ? Math.min(500, 80 + profile.getCollectionList().size() * 36)
            : 140;

        setSize(300, height);
        setLocationRelativeTo(parent);
        setVisible(true);
    }

    // =========================================================================
    // Unregistered view
    // =========================================================================

    private void buildUnregisteredView(JPanel content, String rsn) {
        JLabel icon = new JLabel("📋");
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        icon.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(icon);
        content.add(Box.createVerticalStrut(8));

        JLabel nameLabel = new JLabel(rsn);
        nameLabel.setFont(FontManager.getRunescapeBoldFont().deriveFont(13f));
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(nameLabel);
        content.add(Box.createVerticalStrut(4));

        JLabel statusLabel = new JLabel("Unregistered User");
        statusLabel.setFont(FontManager.getRunescapeSmallFont());
        statusLabel.setForeground(MISSING_COLOR);
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(statusLabel);
        content.add(Box.createVerticalStrut(6));

        JLabel hint = new JLabel("<html><center>This player hasn't registered<br>as a collector yet.</center></html>");
        hint.setFont(FontManager.getRunescapeSmallFont());
        hint.setForeground(Color.GRAY);
        hint.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(hint);
    }

    // =========================================================================
    // Collection view
    // =========================================================================

    private void buildCollectionView(JPanel content, CollectorProfile profile) {
        // Header
        JLabel nameLabel = new JLabel(profile.getRsn() + "'s Collection");
        nameLabel.setFont(FontManager.getRunescapeBoldFont().deriveFont(13f));
        nameLabel.setForeground(HEADER_COLOR);
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(nameLabel);
        content.add(Box.createVerticalStrut(2));

        // Collection label
        if (profile.getCollectionLabel() != null && !profile.getCollectionLabel().isBlank()) {
            JLabel labelTag = new JLabel("\"" + profile.getCollectionLabel() + "\"");
            labelTag.setFont(FontManager.getRunescapeSmallFont());
            labelTag.setForeground(Color.LIGHT_GRAY);
            labelTag.setAlignmentX(Component.LEFT_ALIGNMENT);
            content.add(labelTag);
            content.add(Box.createVerticalStrut(4));
        }

        // Summary bar
        int total = profile.getCollectionList().size();
        int done = profile.getCompletedCount();
        JLabel summaryLabel = new JLabel(done + " / " + total + " obtained");
        summaryLabel.setFont(FontManager.getRunescapeSmallFont());
        summaryLabel.setForeground(done == total ? COMPLETED_COLOR : Color.LIGHT_GRAY);
        summaryLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(summaryLabel);
        content.add(Box.createVerticalStrut(2));

        // Progress bar
        JProgressBar progressBar = new JProgressBar(0, total);
        progressBar.setValue(done);
        progressBar.setStringPainted(false);
        progressBar.setForeground(done == total ? COMPLETED_COLOR : HEADER_COLOR);
        progressBar.setBackground(new Color(55, 55, 55));
        progressBar.setBorderPainted(false);
        progressBar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 6));
        progressBar.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(progressBar);
        content.add(Box.createVerticalStrut(10));

        // Divider
        JSeparator sep = new JSeparator();
        sep.setForeground(BORDER_COLOR);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        content.add(sep);
        content.add(Box.createVerticalStrut(8));

        // Items list
        for (CollectionItem item : profile.getCollectionList()) {
            content.add(buildItemRow(item));
            content.add(Box.createVerticalStrut(4));
        }

        // Last sync footer
        if (profile.getLastSyncTimestamp() > 0) {
            content.add(Box.createVerticalStrut(6));
            String syncTime = new java.text.SimpleDateFormat("MMM d, HH:mm")
                .format(new java.util.Date(profile.getLastSyncTimestamp()));
            JLabel syncLabel = new JLabel("Last bank sync: " + syncTime);
            syncLabel.setFont(FontManager.getRunescapeSmallFont());
            syncLabel.setForeground(Color.DARK_GRAY);
            syncLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            content.add(syncLabel);
        }
    }

    private JPanel buildItemRow(CollectionItem item) {
        JPanel row = new JPanel(new BorderLayout(8, 0));
        row.setBackground(CARD_BG);
        row.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        // Status dot
        JLabel dot = new JLabel(item.isCompleted() ? "●" : "○");
        dot.setForeground(item.isCompleted() ? COMPLETED_COLOR : MISSING_COLOR);
        dot.setFont(new Font("Dialog", Font.PLAIN, 10));
        row.add(dot, BorderLayout.WEST);

        // Item name
        JLabel nameLabel = new JLabel(item.getItemName());
        nameLabel.setFont(FontManager.getRunescapeSmallFont());
        nameLabel.setForeground(item.isCompleted() ? COMPLETED_COLOR : Color.WHITE);
        row.add(nameLabel, BorderLayout.CENTER);

        // Quantity
        JLabel qtyLabel = new JLabel(item.getProgressString());
        qtyLabel.setFont(FontManager.getRunescapeSmallFont());
        qtyLabel.setForeground(item.isCompleted() ? COMPLETED_COLOR : Color.GRAY);
        row.add(qtyLabel, BorderLayout.EAST);

        return row;
    }
}
