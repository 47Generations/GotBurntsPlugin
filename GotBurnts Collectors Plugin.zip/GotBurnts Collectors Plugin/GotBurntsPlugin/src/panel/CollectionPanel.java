package com.collectorplugin.panel.src.panel;

import com.collectorplugin.panel.src.main.java.com.gotburnts.CollectorConfig;
import com.collectorplugin.panel.src.main.java.com.gotburnts.CollectorPlugin;
import com.collectorplugin.panel.src.model.CollectionItem;
import net.runelite.client.ui.ColorScheme;
import net.runelite.client.ui.FontManager;
import net.runelite.client.ui.PluginPanel;

import javax.inject.Inject;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * The main plugin side panel.
 * Allows the player to register as a collector and manage their 20 items.
 */
public class CollectionPanel extends PluginPanel {

    private static final int MAX_ITEMS = 20;
    private static final Color HEADER_COLOR = new Color(255, 152, 0);       // Orange
    private static final Color COMPLETED_COLOR = new Color(76, 175, 80);    // Green
    private static final Color MISSING_COLOR = new Color(244, 67, 54);      // Red
    private static final Color CARD_BG = new Color(40, 40, 40);

    private final CollectorPlugin plugin;
    private final CollectorConfig config;

    // Registration header
    private JLabel statusLabel;
    private JButton registerButton;

    // Collection label
    private JTextField labelField;

    // Item rows
    private final List<ItemRowPanel> itemRows = new ArrayList<>();
    private JPanel itemListPanel;

    // Save button
    private JButton saveButton;
    private JLabel syncStatusLabel;

    @Inject
    public CollectionPanel(CollectorPlugin plugin, CollectorConfig config) {
        this.plugin = plugin;
        this.config = config;

        setLayout(new BorderLayout());
        setBackground(ColorScheme.DARK_GRAY_COLOR);
        setBorder(new EmptyBorder(10, 10, 10, 10));

        buildUI();
    }

    // =========================================================================
    // UI Construction
    // =========================================================================

    private void buildUI() {
        JPanel wrapper = new JPanel();
        wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        wrapper.setBackground(ColorScheme.DARK_GRAY_COLOR);

        // --- Title ---
        JLabel title = new JLabel("Collector Plugin");
        title.setFont(FontManager.getRunescapeBoldFont().deriveFont(16f));
        title.setForeground(HEADER_COLOR);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrapper.add(title);
        wrapper.add(Box.createVerticalStrut(4));

        JLabel subtitle = new JLabel("Register & manage your collection");
        subtitle.setFont(FontManager.getRunescapeSmallFont());
        subtitle.setForeground(Color.LIGHT_GRAY);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrapper.add(subtitle);
        wrapper.add(Box.createVerticalStrut(12));

        // --- Registration Status ---
        JPanel statusPanel = buildStatusPanel();
        statusPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrapper.add(statusPanel);
        wrapper.add(Box.createVerticalStrut(10));

        // --- Collection Label ---
        JLabel labelTitle = buildSectionLabel("Collection Label");
        labelTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrapper.add(labelTitle);
        wrapper.add(Box.createVerticalStrut(4));

        labelField = new JTextField(config.collectionLabel());
        labelField.setBackground(CARD_BG);
        labelField.setForeground(Color.WHITE);
        labelField.setCaretColor(Color.WHITE);
        labelField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(ColorScheme.MEDIUM_GRAY_COLOR),
            BorderFactory.createEmptyBorder(4, 6, 4, 6)
        ));
        labelField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        labelField.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrapper.add(labelField);
        wrapper.add(Box.createVerticalStrut(12));

        // --- Items Section ---
        JLabel itemsTitle = buildSectionLabel("Collection Items (up to " + MAX_ITEMS + ")");
        itemsTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrapper.add(itemsTitle);
        wrapper.add(Box.createVerticalStrut(4));

        JLabel itemsHint = new JLabel("Enter item name + goal qty. Bank sync updates quantity.");
        itemsHint.setFont(FontManager.getRunescapeSmallFont());
        itemsHint.setForeground(Color.GRAY);
        itemsHint.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrapper.add(itemsHint);
        wrapper.add(Box.createVerticalStrut(6));

        itemListPanel = new JPanel();
        itemListPanel.setLayout(new BoxLayout(itemListPanel, BoxLayout.Y_AXIS));
        itemListPanel.setBackground(ColorScheme.DARK_GRAY_COLOR);
        itemListPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Load existing items from plugin
        List<CollectionItem> existing = plugin.getMyCollectionItems();
        for (int i = 0; i < MAX_ITEMS; i++) {
            CollectionItem item = i < existing.size() ? existing.get(i) : null;
            ItemRowPanel row = new ItemRowPanel(i + 1, item);
            itemRows.add(row);
            itemListPanel.add(row);
            itemListPanel.add(Box.createVerticalStrut(4));
        }

        wrapper.add(itemListPanel);
        wrapper.add(Box.createVerticalStrut(12));

        // --- Save / Sync ---
        saveButton = new JButton("Save & Sync Collection");
        saveButton.setBackground(HEADER_COLOR);
        saveButton.setForeground(Color.BLACK);
        saveButton.setFont(FontManager.getRunescapeBoldFont());
        saveButton.setFocusPainted(false);
        saveButton.setBorderPainted(false);
        saveButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        saveButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        saveButton.addActionListener(e -> onSaveClicked());
        wrapper.add(saveButton);
        wrapper.add(Box.createVerticalStrut(6));

        syncStatusLabel = new JLabel(" ");
        syncStatusLabel.setFont(FontManager.getRunescapeSmallFont());
        syncStatusLabel.setForeground(Color.GRAY);
        syncStatusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrapper.add(syncStatusLabel);

        // Wrap in scroll pane
        JScrollPane scrollPane = new JScrollPane(wrapper);
        scrollPane.setBorder(null);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getViewport().setBackground(ColorScheme.DARK_GRAY_COLOR);

        add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel buildStatusPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        panel.setBackground(ColorScheme.DARK_GRAY_COLOR);

        statusLabel = new JLabel(config.isRegistered() ? "✓ Registered" : "✗ Not Registered");
        statusLabel.setFont(FontManager.getRunescapeSmallFont());
        statusLabel.setForeground(config.isRegistered() ? COMPLETED_COLOR : MISSING_COLOR);
        panel.add(statusLabel);

        registerButton = new JButton(config.isRegistered() ? "Unregister" : "Register");
        registerButton.setFont(FontManager.getRunescapeSmallFont());
        registerButton.setFocusPainted(false);
        registerButton.addActionListener(e -> onRegisterToggle());
        styleSmallButton(registerButton, config.isRegistered());
        panel.add(registerButton);

        return panel;
    }

    private JLabel buildSectionLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(FontManager.getRunescapeBoldFont());
        label.setForeground(Color.WHITE);
        return label;
    }

    private void styleSmallButton(JButton button, boolean isActive) {
        if (isActive) {
            button.setBackground(new Color(80, 80, 80));
            button.setForeground(Color.LIGHT_GRAY);
        } else {
            button.setBackground(HEADER_COLOR);
            button.setForeground(Color.BLACK);
        }
        button.setBorderPainted(false);
    }

    // =========================================================================
    // Actions
    // =========================================================================

    private void onRegisterToggle() {
        boolean nowRegistered = !config.isRegistered();
        plugin.setRegistered(nowRegistered);

        statusLabel.setText(nowRegistered ? "✓ Registered" : "✗ Not Registered");
        statusLabel.setForeground(nowRegistered ? COMPLETED_COLOR : MISSING_COLOR);
        registerButton.setText(nowRegistered ? "Unregister" : "Register");
        styleSmallButton(registerButton, nowRegistered);

        setSyncStatus(nowRegistered ? "Registered! Save your items below." : "Unregistered.", false);
    }

    private void onSaveClicked() {
        List<CollectionItem> items = new ArrayList<>();

        for (ItemRowPanel row : itemRows) {
            CollectionItem item = row.getItem();
            if (item != null && !item.getItemName().isBlank()) {
                items.add(item);
            }
        }

        if (items.size() > MAX_ITEMS) {
            setSyncStatus("Too many items! Max " + MAX_ITEMS + ".", true);
            return;
        }

        String label = labelField.getText().trim();
        if (label.isEmpty()) {
            label = "My Collection";
        }

        plugin.saveCollection(label, items,
            () -> SwingUtilities.invokeLater(() ->
                setSyncStatus("✓ Saved & synced! (" + items.size() + " items)", false)),
            err -> SwingUtilities.invokeLater(() ->
                setSyncStatus("✗ Error: " + err, true))
        );

        setSyncStatus("Saving...", false);
    }

    // =========================================================================
    // Public update methods (called from plugin thread)
    // =========================================================================

    /**
     * Called after a bank sync to update the displayed quantities.
     */
    public void updateQuantities(List<CollectionItem> updatedItems) {
        SwingUtilities.invokeLater(() -> {
            for (int i = 0; i < itemRows.size() && i < updatedItems.size(); i++) {
                itemRows.get(i).setCurrentQuantity(updatedItems.get(i).getCurrentQuantity());
            }
            setSyncStatus("✓ Bank synced at " + java.time.LocalTime.now()
                .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")), false);
        });
    }

    public void setSyncStatus(String message, boolean isError) {
        syncStatusLabel.setText(message);
        syncStatusLabel.setForeground(isError ? MISSING_COLOR : COMPLETED_COLOR);
    }

    // =========================================================================
    // Inner class: one item row
    // =========================================================================

    private static class ItemRowPanel extends JPanel {

        private final JTextField nameField;
        private final JSpinner goalSpinner;
        private final JLabel quantityLabel;
        private int currentQuantity = 0;

        ItemRowPanel(int index, CollectionItem existing) {
            setLayout(new GridBagLayout());
            setBackground(CARD_BG);
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 60, 60)),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)
            ));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 52));

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(1, 2, 1, 2);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            // Row number
            JLabel numLabel = new JLabel(index + ".");
            numLabel.setFont(FontManager.getRunescapeSmallFont());
            numLabel.setForeground(Color.GRAY);
            numLabel.setPreferredSize(new Dimension(18, 16));
            gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
            add(numLabel, gbc);

            // Item name field
            nameField = new JTextField(existing != null ? existing.getItemName() : "");
            nameField.setBackground(new Color(50, 50, 50));
            nameField.setForeground(Color.WHITE);
            nameField.setCaretColor(Color.WHITE);
            nameField.setFont(FontManager.getRunescapeSmallFont());
            nameField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(70, 70, 70)),
                BorderFactory.createEmptyBorder(2, 4, 2, 4)
            ));
            gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
            add(nameField, gbc);

            // Goal spinner
            int goal = existing != null ? existing.getGoalQuantity() : 1;
            goalSpinner = new JSpinner(new SpinnerNumberModel(goal, 1, 999999, 1));
            goalSpinner.setPreferredSize(new Dimension(55, 20));
            goalSpinner.setBackground(new Color(50, 50, 50));
            ((JSpinner.DefaultEditor) goalSpinner.getEditor()).getTextField()
                .setBackground(new Color(50, 50, 50));
            ((JSpinner.DefaultEditor) goalSpinner.getEditor()).getTextField()
                .setForeground(Color.WHITE);
            gbc.gridx = 2; gbc.gridy = 0; gbc.weightx = 0;
            add(goalSpinner, gbc);

            // Quantity label (bank sync)
            currentQuantity = existing != null ? existing.getCurrentQuantity() : 0;
            quantityLabel = new JLabel("qty: " + currentQuantity);
            quantityLabel.setFont(FontManager.getRunescapeSmallFont());
            quantityLabel.setForeground(currentQuantity >= goal ? COMPLETED_COLOR : Color.GRAY);
            gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0; gbc.gridwidth = 2;
            add(quantityLabel, gbc);
        }

        CollectionItem getItem() {
            String name = nameField.getText().trim();
            if (name.isEmpty()) return null;
            int goal = (int) goalSpinner.getValue();
            return new CollectionItem(0, name, currentQuantity, goal);
        }

        void setCurrentQuantity(int qty) {
            this.currentQuantity = qty;
            int goal = (int) goalSpinner.getValue();
            quantityLabel.setText("qty: " + qty);
            quantityLabel.setForeground(qty >= goal ? COMPLETED_COLOR : Color.GRAY);
        }
    }
}
